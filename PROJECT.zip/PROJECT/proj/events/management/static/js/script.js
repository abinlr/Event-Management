document.addEventListener('DOMContentLoaded', () => {
    // Toggle Navbar (Hamburger Menu)
    const menuBars = document.getElementById("menu-bars");
    const navbar = document.getElementById("navbar");
    document.getElementById('menu-bars').addEventListener('click', function() {
        document.querySelector('.navbar').classList.toggle('active');
    });    

    if (menuBars && navbar) {
        menuBars.addEventListener('click', () => {
            navbar.classList.toggle('active');
        });
    }

    // Image Slider (using Swiper.js for the home section)
    if (document.querySelector('.swiper-container')) {
        new Swiper('.swiper-container', {
            loop: true,
            spaceBetween: 0,
            slidesPerView: 3,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });
    }

    // Form Validation (for login)
    // const loginForm = document.getElementById('login-form');
    // if (loginForm) {
    //     loginForm.addEventListener('submit', function(event) {
    //         event.preventDefault();

    //         const emailInput = document.getElementById('email');
    //         const passwordInput = document.getElementById('password');
    //         let isValid = true;
    //         let errorMessage = '';

    //         if (emailInput) {
    //             const emailValue = emailInput.value.trim();
    //             if (!/\S+@\S+\.\S+/.test(emailValue)) {
    //                 isValid = false;
    //                 errorMessage += 'Please enter a valid email.\n';
    //             }
    //         }

    //         if (passwordInput) {
    //             const passwordValue = passwordInput.value.trim();
    //             if (passwordValue.length < 6) {
    //                 isValid = false;
    //                 errorMessage += 'Password must be at least 6 characters long.\n';
    //             }
    //         }

    //         if (isValid) {
    //             loginForm.submit();
    //         } else {
    //             alert(errorMessage);
    //         }
    //     });
    // }

    // Scroll-to-Top Button
    const scrollTopBtn = document.getElementById('scroll-top-btn');
    if (scrollTopBtn) {
        window.addEventListener('scroll', () => {
            scrollTopBtn.classList.toggle('visible', window.scrollY > 200);
        });

        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Smooth Scroll for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetElement = document.getElementById(this.getAttribute('href').substring(1));
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
});


