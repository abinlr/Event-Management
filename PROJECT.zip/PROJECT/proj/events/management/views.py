from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.contrib import messages
from django.contrib import auth
from django.contrib.auth.models import User



def index(request):
    return render(request, 'index.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(request, username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('index')
        else:
            error_message = 'Invalid username or password'
            return render(request, 'login.html', {'error_message': error_message})
    else:
        return render(request, 'login.html')

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 == password2:
            try:
                user = User.objects.create_user(username, email, password1)
                user.save()
                auth.login(request, user)
                return redirect('login_view')
            except:
                return render(request, 'register.html', {'error_message': 'Error creating account'})
        else:
            return render(request, 'register.html', {'error_message': 'Passwords do not match'})

    return render(request, 'register.html')

def contact(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        eventname = request.POST['event_name']  # ✅ Fixed key name
        message = request.POST['message']
        
        subject = f"New Contact Form Submission from {name}"
        email_message = f"Name: {name}\nEmail: {email}\nPhone: {phone}\nEvent: {eventname}\nMessage:\n{message}"
        
        try:
            send_mail(
                subject,
                email_message,
                'youremail@yourdomain.com',  # ✅ Use your verified email
                ['abin98018@gmail.com'],  # Receiver email
                fail_silently=False,
            )
            messages.success(request, "Your message has been sent successfully! ✅")
        except Exception as e:
            messages.error(request, "Oops! Something went wrong. Please try again. ❌")

        return redirect('index')  # ✅ Redirect to the correct page
    
    return render(request, 'index.html')

def message(request):
    messages.success(request, 'Your action was successful!')
    return render(request, 'index.html')

def logout_view(request):
    auth.logout(request)
    return redirect('index')

def index_view(request):
    return render(request, 'index.html')


