from django.contrib.auth import views as auth_views
from django.urls import path
from . import views

urlpatterns = [  
    path('index/', views.index, name='index'),  # Home page
    path('', views.login_view, name='login_view'),  
    path('register/', views.register, name='register'),
    path('contact/', views.contact, name='contact'),  
    path('message/', views.message, name='message'),
]

